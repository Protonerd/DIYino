/*
 * Config.h
 *
 * author: 		Sebastien CAPOU (neskweek@gmail.com) and Andras Kun (kun.andras@yahoo.de)
 * Source : 	https://github.com/neskweek/LightSaberOS
 */

#include <Arduino.h>
#if not defined CONFIGMENU_H_
#define CONFIGMENU_H_

#include <WS2812.h>

enum SaberStateEnum {S_STANDBY, S_SABERON, S_CONFIG, S_SLEEP, S_JUKEBOX};
// an unified enumeration type of all sub stats for both action mode (S_SaberON) and config mode (S_CONFIG)
//enum SubStateEnum {AS_HUM, AS_IGNITION, AS_RETRACTION, AS_BLADELOCKUP, AS_PREBLADELOCKUP, AS_BLASTERDEFLECTMOTION, AS_BLASTERDEFLECTPRESS, AS_CLASH, AS_SWING, AS_SPIN, AS_FORCE,CS_VOLUME, CS_SOUNDFONT, CS_MAINCOLOR, CS_CLASHCOLOR, CS_BLASTCOLOR, CS_FLICKERTYPE, CS_POWERONOFFTYPE, CS_SWINGSENSITIVITY, CS_SLEEPINIT, CS_BATTERYLEVEL, CS_STORAGEACCESS, CS_UARTMODE};
enum ActionModeSubStatesEnum {AS_HUM, AS_IGNITION, AS_RETRACTION, AS_BLADELOCKUP, AS_PREBLADELOCKUP, AS_BLASTERDEFLECTMOTION, AS_BLASTERDEFLECTPRESS, AS_CLASH, AS_SWING, AS_SPIN, AS_FORCE};
enum ConfigModeSubStatesEnum {CS_BATTERYLEVEL, CS_SOUNDFONT, CS_SLEEPINIT, CS_MAINCOLOR, CS_CLASHCOLOR, CS_BLASTCOLOR, CS_VOLUME, CS_FLICKERTYPE, CS_POWERONOFFTYPE, CS_SWINGSENSITIVITY, CS_STORAGEACCESS, CS_UARTMODE};



// ====================================================================================
// ===           	  	 			CONFIG MODE FUNCTIONS	                		===
// ====================================================================================

void confParseValue(uint16_t variable, uint16_t min, uint16_t max,
		short int multiplier);

void NextConfigState();

#endif /* CONFIG_H_ */


